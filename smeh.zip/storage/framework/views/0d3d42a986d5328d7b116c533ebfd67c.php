<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> <?php echo $__env->yieldContent('title' , $setting->translate(app()->getlocale())->title); ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name ="description", content="<?php echo $__env->yieldContent('meta_description',  $setting->content ); ?>">
    <meta name ="keywords", content="<?php echo $__env->yieldContent('meta_keywords',  $setting->title ); ?>">
    <!-- Favicon -->
    <link href="<?php echo e(asset($setting->favicon)); ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('front')); ?>/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('front')); ?>/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row align-items-center bg-light px-lg-5">
            <div class="col-12 col-md-8">
                <div class="d-flex justify-content-between">
                    <div class="bg-primary text-white text-center py-2" style="width: 100px;">Tranding</div>
                    <div class="owl-carousel owl-carousel-1 tranding-carousel position-relative d-inline-flex align-items-center ml-3"
                        style="width: calc(100% - 100px); padding-left: 90px;">
                        <?php $__currentLoopData = $lastFivePosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="text-truncate"><a class="text-secondary" href="<?php echo e(Route('post',$post->id)); ?>"><?php echo e($post->title); ?></a></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-4 text-right d-none d-md-block">
                <?php echo e(Date('D Y,M,d')); ?>

            </div>
        </div>
        <div class="row align-items-center py-2 px-lg-5">
            <div class="col-lg-4">
                <a href="<?php echo e(route('index')); ?>" class="navbar-brand d-none d-lg-block">
                    <img src="<?php echo e(asset($setting->logo)); ?>" alt="" style="height: 70px">
                </a>
            </div>
            <div class="col-lg-8 text-center text-lg-right">
                <img class="img-fluid" src="<?php echo e(asset($setting->logo)); ?>" alt="" style="height: 70px">
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0 mb-3">
        <nav class="navbar navbar-expand-lg bg-light navbar-light py-2 py-lg-0 px-lg-5" >
            <a href="" class="navbar-brand d-block d-lg-none">
                <h1 class="m-0 display-5 text-uppercase"><span class="text-primary">News</span>Room</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse" >
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-0 px-lg-3" id="navbarCollapse"  style="background-color: rgb(47, 47, 148);
            ">
                <div class="navbar-nav mr-auto py-0">
                    <a href="<?php echo e(route('index')); ?>" class="nav-item nav-link active"><?php echo e(__('words.home')); ?></a>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="nav-item dropdown" >
                            <a  <?php if(count($category->children) == 0): ?> href="<?php echo e(Route('category',$category->id)); ?>" <?php else: ?> href='#' <?php endif; ?> class="nav-link  <?php if(count($category->children) > 0): ?> dropdown-toggle  <?php endif; ?>"
                                <?php if(count($category->children) > 0): ?>  data-toggle="dropdown" <?php endif; ?>
                                 ><?php echo e($category->title); ?></a>
                            <?php if(count($category->children) > 0): ?>
                                <div class="dropdown-menu rounded-0 m-0">
                                    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(Route('category',$child->id)); ?>" class="dropdown-item"><?php echo e($child->title); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







                </div>


                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button"
                        aria-haspopup="true" aria-expanded="false">
                        <span class="hidden-md-down"><?php echo e(LaravelLocalization::getCurrentLocaleNative()); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">

                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                <?php echo e($properties['native']); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </li>




                <div class="input-group ml-auto" style="width: 100%; max-width: 300px;">
                    <input type="text" class="form-control" placeholder="Keyword">
                    <div class="input-group-append">
                        <button class="input-group-text text-secondary"><i class="fa fa-search"></i></button>
                    </div>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

    <?php echo $__env->yieldContent('body'); ?>





    <!-- Footer Start -->
    <div class="container-fluid bg-light pt-5 px-sm-3 px-md-5">
        <div class="row">
            <div class="col-lg-6 col-md-6 mb-5">
                <a href="index.html" class="navbar-brand">
                    <img src="<?php echo e(asset($setting->logo)); ?>" alt="" style="height: 70px">
                </a>
                <p><?php echo e($setting->translate(app()->getlocale())->content); ?></p>
                <div class="d-flex justify-content-start mt-4">

                    <?php if($setting->facebook != ''): ?>
                        <a class="btn btn-outline-secondary text-center mr-2 px-0" style="width: 38px; height: 38px;"
                            href="<?php echo e($setting->facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                    <?php endif; ?>

                    <?php if($setting->instagram != ''): ?>
                        <a class="btn btn-outline-secondary text-center mr-2 px-0" style="width: 38px; height: 38px;"
                            href="<?php echo e($setting->instagram); ?>"><i class="fab fa-instagram"></i></a>
                    <?php endif; ?>

                </div>
            </div>
            <div class="col-lg-6 col-md-6 mb-5">
                <h4 class="font-weight-bold mb-4"><?php echo e(__('words.categories')); ?></h4>
                <div class="d-flex flex-wrap m-n1">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(Route('category',$category->id)); ?>" class="btn btn-sm btn-outline-secondary m-1"><?php echo e($category->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-4 px-sm-3 px-md-5">
        <p class="m-0 text-center">
            &copy; <a class="font-weight-bold" href="#">Your Site Name</a>. All Rights Reserved.

            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
            Designed by <a class="font-weight-bold" href="https://htmlcodex.com">HTML Codex</a>
        </p>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-dark back-to-top"><i class="fa fa-angle-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('front')); ?>/lib/easing/easing.min.js"></script>
    <script src="<?php echo e(asset('front')); ?>/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="<?php echo e(asset('front')); ?>/mail/jqBootstrapValidation.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('front')); ?>/js/main.js"></script>
</body>

</html>
<?php /**PATH C:\Users\rabeaa\smeh\resources\views/website/layout/layout.blade.php ENDPATH**/ ?>