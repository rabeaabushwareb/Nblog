<?php $__env->startSection('body'); ?>
    <!-- Breadcrumb -->
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><?php echo e(__('words.dashboard')); ?></li>
        <li class="breadcrumb-item"><a href="#"><?php echo e(__('words.users')); ?></a>
        </li>
        <li class="breadcrumb-item active"><?php echo e($user->name); ?></li>

        <!-- Breadcrumb Menu-->
        <li class="breadcrumb-menu">
            <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
                <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;<?php echo e(__('words.users')); ?></a>
                <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;<?php echo e($user->name); ?></a>
            </div>
        </li>
    </ol>


    <div class="container-fluid">

        <div class="animated fadeIn">
            <form action="<?php echo e(Route('dashboard.users.update', $user)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <strong><?php echo e(__('words.users')); ?></strong>
                        </div>
                        <div class="card-block">




                            <div class="form-group col-md-12">
                                <label><?php echo e(__('words.name')); ?></label>
                                <input type="text" name="name" class="form-control" placeholder="<?php echo e(__('words.name')); ?>"
                                    value="<?php echo e($user->name); ?>">
                            </div>
                            <div class="form-group col-md-12">
                                <label><?php echo e(__('words.email')); ?></label>
                                <input type="text" name="email" class="form-control"
                                    placeholder="<?php echo e(__('words.email')); ?>" value="<?php echo e($user->email); ?>">
                            </div>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', $user)): ?>


                            <div class="form-group col-md-12">
                                <label><?php echo e(__('words.status')); ?></label>
                                <select name="status" id="" class="form-control">

                                    <option value="admin" <?php if($user->status == 'admin'): ?>
                                        selected
                                    <?php endif; ?>>Admin</option>
                                    <option value="writer" <?php if($user->status == 'Writer'): ?>
                                        selected
                                    <?php endif; ?>>Writer</option>
                                    <option value="" <?php if($user->status == ''): ?>
                                        selected
                                    <?php endif; ?>>غير مفعل </option>
                                </select>

                            </div>
                            <?php endif; ?>
                        </div>




                        <div class="card-footer">
                            <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-dot-circle-o"></i>
                                Submit</button>
                            <button type="reset" class="btn btn-sm btn-danger"><i class="fa fa-ban"></i>
                                Reset</button>
                        </div>



                    </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ربيع ابو شوارب\smeh\resources\views/dashboard/users/edit.blade.php ENDPATH**/ ?>